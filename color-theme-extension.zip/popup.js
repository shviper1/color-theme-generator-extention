// popup.js - Logic for the popup interface

let selectedThemeId = null;

// Function to render theme cards
function renderThemes() {
    const themeGrid = document.getElementById('theme-grid');
    const themes = getAvailableThemes();

    themeGrid.innerHTML = '';

    themes.forEach(theme => {
        const card = document.createElement('div');
        card.className = 'theme-card';
        card.dataset.themeId = theme.id;

        card.innerHTML = `
      <div class="theme-name">${theme.name}</div>
      <div class="color-preview">
        <div class="color-box" style="background-color: ${theme.background}" title="Background"></div>
        <div class="color-box" style="background-color: ${theme.primary}" title="Primary"></div>
        <div class="color-box" style="background-color: ${theme.secondary}" title="Secondary"></div>
        <div class="color-box" style="background-color: ${theme.accent}" title="Accent"></div>
      </div>
      <div class="color-labels">
        <span>BG</span>
        <span>Primary</span>
        <span>Secondary</span>
        <span>Accent</span>
      </div>
      <div class="theme-actions">
        <button class="btn btn-primary apply-btn" data-theme-id="${theme.id}">Apply Theme</button>
        <button class="btn btn-success save-btn" data-theme-id="${theme.id}">Save Theme</button>
      </div>
    `;

        themeGrid.appendChild(card);
    });

    // Add event listeners
    document.querySelectorAll('.apply-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const themeId = e.target.dataset.themeId;
            applyThemeToCurrentTab(themeId);
            updateSelectedTheme(themeId);
        });
    });

    document.querySelectorAll('.save-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const themeId = e.target.dataset.themeId;
            saveThemeForCurrentTab(themeId);
        });
    });

    document.querySelectorAll('.theme-card').forEach(card => {
        card.addEventListener('click', (e) => {
            if (!e.target.classList.contains('btn')) {
                const themeId = card.dataset.themeId;
                applyThemeToCurrentTab(themeId);
                updateSelectedTheme(themeId);
            }
        });
    });
}

// Function to apply theme to current tab
async function applyThemeToCurrentTab(themeId) {
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab.url || !tab.url.startsWith('http')) {
            alert('Cannot apply theme to this page. Please navigate to a website.');
            return;
        }
        const theme = getTheme(themeId);
        if (!theme) return;
        const css = generateThemeCSS(theme);

        // Remove existing theme styles
        await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            function: () => {
                const existing = document.getElementById('color-theme-suggester-styles');
                if (existing) existing.remove();
                const highlight = document.getElementById('highlight-styles');
                if (highlight) highlight.remove();
            }
        });

        // Inject new theme styles
        await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            function: (css) => {
                const style = document.createElement('style');
                style.id = 'color-theme-suggester-styles';
                style.textContent = css;
                document.head.appendChild(style);
            },
            args: [css]
        });
    } catch (error) {
        console.error('Error applying theme:', error);
        alert('Failed to apply theme. Please try again.');
    }
}// Function to save theme for current tab's URL
async function saveThemeForCurrentTab(themeId) {
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab.url || !tab.url.startsWith('http')) {
            alert('Cannot save theme for this page. Please navigate to a website.');
            return;
        }
        const hostname = new URL(tab.url).hostname;
        await chrome.storage.sync.set({ [hostname]: themeId });
        alert('Theme saved for this website!');
    } catch (error) {
        console.error('Error saving theme:', error);
        alert('Failed to save theme. Please try again.');
    }
}

// Function to reset theme
async function resetTheme() {
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab.url || !tab.url.startsWith('http')) {
            alert('Cannot reset theme on this page. Please navigate to a website.');
            return;
        }
        // Remove theme styles
        await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            function: () => {
                const existing = document.getElementById('color-theme-suggester-styles');
                if (existing) existing.remove();
                const highlight = document.getElementById('highlight-styles');
                if (highlight) highlight.remove();
            }
        });
        updateSelectedTheme(null);
    } catch (error) {
        console.error('Error resetting theme:', error);
        alert('Failed to reset theme. Please try again.');
    }
}

// Function to highlight elements that will be affected by the theme
async function highlightElements(themeId) {
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab.url || !tab.url.startsWith('http')) {
            alert('Cannot highlight on this page. Please navigate to a website.');
            return;
        }
        const theme = getTheme(themeId);
        if (!theme) return;

        // Selectors that will be styled
        const selectors = ['body', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'div', 'span', 'section', 'article', 'header', 'footer', 'nav', 'aside', 'main', 'a', 'button', '.btn', 'input[type="submit"]', 'input[type="button"]', '.card', '.panel'];

        // Create CSS to highlight these elements with subtle effect
        const highlightCSS = selectors.map(sel => `${sel} { outline: 1px solid ${hexToRgba(theme.accent, 0.3)} !important; }`).join('\n');

        // Remove existing highlights
        await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            function: () => {
                const existing = document.getElementById('highlight-styles');
                if (existing) existing.remove();
            }
        });

        // Add highlight styles
        await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            function: (css) => {
                const style = document.createElement('style');
                style.id = 'highlight-styles';
                style.textContent = css;
                document.head.appendChild(style);
            },
            args: [highlightCSS]
        });
    } catch (error) {
        console.error('Error highlighting elements:', error);
        alert('Failed to highlight elements. Please try again.');
    }
}

// Function to update selected theme visual
function updateSelectedTheme(themeId) {
    document.querySelectorAll('.theme-card').forEach(card => {
        card.classList.remove('selected');
    });

    if (themeId) {
        const selectedCard = document.querySelector(`[data-theme-id="${themeId}"]`);
        if (selectedCard) {
            selectedCard.classList.add('selected');
        }
    }

    selectedThemeId = themeId;
}

// Event listeners
document.getElementById('reset-btn').addEventListener('click', resetTheme);
document.getElementById('highlight-btn').addEventListener('click', () => {
    if (selectedThemeId) {
        highlightElements(selectedThemeId);
    } else {
        alert('Please select a theme first.');
    }
});

// Initialize popup
document.addEventListener('DOMContentLoaded', () => {
    renderThemes();
});